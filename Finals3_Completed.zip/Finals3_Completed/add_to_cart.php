<?php
include 'connect.php'; // Database connection
session_start();

// Replace with dynamic user ID (update when user authentication is implemented)
$userId = 1; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input
    $productName = $conn->real_escape_string($_POST['product_name']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);

    // Check if the product already exists in the cart
    $checkQuery = "SELECT * FROM cart WHERE product_name = '$productName' AND user_id = $userId";
    $result = $conn->query($checkQuery);

    if ($result->num_rows > 0) {
        // Update quantity if the product exists
        $updateQuery = "UPDATE cart SET quantity = quantity + $quantity WHERE product_name = '$productName' AND user_id = $userId";
        $conn->query($updateQuery);
    } else {
        // Insert new product into the cart
        $insertQuery = "INSERT INTO cart (user_id, product_name, price, quantity) VALUES ($userId, '$productName', $price, $quantity)";
        $conn->query($insertQuery);
    }

    echo json_encode(['success' => true, 'message' => 'Product added to cart!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>

