<?php
include 'connect.php'; // Database connection
session_start();

// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

// Get product details from the request
$product_name = $conn->real_escape_string($_POST['product_name']);
$price = floatval($_POST['price']);
$image_url = $conn->real_escape_string($_POST['image_url']);

// Check if the product is already in the wishlist
$sql = "SELECT * FROM wishlist WHERE user_id = $userId AND product_name = '$product_name'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Product already in wishlist!"]);
} else {
    // Insert the product into the wishlist
    $sql = "INSERT INTO wishlist (user_id, product_name, price, image_url) VALUES ($userId, '$product_name', $price, '$image_url')";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true, "message" => "Product added to wishlist!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error adding product to wishlist: " . $conn->error]);
    }
}

$conn->close();
?>
