<?php
// Start session if you need user identification
session_start();

// Database connection
$host = 'localhost';    // Update with your DB host
$username = 'root';     // Update with your DB username
$password = '';         // Update with your DB password
$database = 'glamgrove_db'; // Your database name

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cart items for the user (assume user_id is 1 for now)
$user_id = 1; // Replace with dynamic user ID if needed
$sql = "SELECT * FROM cart WHERE user_id = $user_id";
$result = $conn->query($sql);

// Prepare data for rendering
$cart_items = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cart_items[] = $row;
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart - GlamGrove</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
       .cart-section,
.cart-table,
.cart-table th, 
.cart-table td ,
.cart-container,
.cart-form,
.cart-count,
.cart-total,
.cart-summary
{
    background-color: pink;
    color : black;
    border-color: black;
}
body.dark-mode .cart-section,
body.dark-mode .cart-table,
body.dark-mode .cart-table th, 
body.dark-mode .cart-table td ,
body.dark-mode .cart-container,
body.dark-mode .cart-form,
body.darl-mode .cart-count,
body.darl-mode .cart-total,
body.dark-mode .cart-summary
{
    background-color: #333;
    color: white;
    border-color: white;
}
    </style>
</head>
<body>

    <!-- Sticky Navigation Bar -->
    <header class="sticky-header">
        <div class="nav-container">
            
            <a href="welcome.html" class="logo">GlamGrove</a>
            <nav>

            <a href="welcome.html">Home</a>
                <a href="shop.html">Shop</a>
                <a href="exclusive-deals.html">Exclusive Deals</a> 
                <a href="wishlist.html">Wishlist</a>
                <a href="contact.html">Contract Us</a>
                <a href="index.html">Login</a>
        <!-- Dark Mode Toggle Button -->
        <button id="dark-mode-toggle" aria-label="Toggle Dark Mode">🌙</button>
            </nav>
        </div>
    </header>

    <!-- Cart Section -->
    <section class="cart-section">
        <br> <br> <br>
        <h2>Your Shopping Cart</h2>

        <!-- Cart Table -->
        <div class="cart-container">
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody id="cart-items">
                <tbody id="cart-items">
    <?php if (!empty($cart_items)): ?>
        <?php foreach ($cart_items as $item): ?>
            <tr>
            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                <td>$<?php echo number_format($item['price'], 2); ?></td>
                <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                <td>
                    <form method="post" action="remove_from_cart.php">
                        <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="remove-button">Remove</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="5">Your cart is empty.</td>
        </tr>
    <?php endif; ?>
</tbody>

                </tbody>
            </table>

            <!-- Cart Summary -->
            <div class="cart-summary">
    <h3>Cart Summary</h3>
    <p>Total Items: <span id="total-items"><?php echo array_sum(array_column($cart_items, 'quantity')); ?></span></p>
    <p>Total Price: $<span id="total-price">
        <?php echo number_format(array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $cart_items)), 2); ?>
    </span></p>
    <button class="checkout-button" id="checkout-button">Proceed to Checkout</button>

</div>

        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>© 2024 GlamGrove. All Rights Reserved.</p>
    </footer>
<!-- Dark Mode JavaScript -->
<script>
    // Select the dark mode toggle button
    const darkModeToggle = document.getElementById("dark-mode-toggle");

    // Check if dark mode was previously enabled
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        darkModeToggle.textContent = "☀️"; // Sun icon for light mode
    }

    // Toggle dark mode on button click 
    darkModeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        
        if (document.body.classList.contains("dark-mode")) {
            // Enable dark mode
            localStorage.setItem("darkMode", "enabled");
            darkModeToggle.textContent = "☀️"; // Update to sun icon
        } else {
            // Disable dark mode
            localStorage.setItem("darkMode", "disabled");
            darkModeToggle.textContent = "🌙"; // Update to moon icon
        }
    });
</script>

    <!-- Inline JavaScript to Handle Cart Functionality -->
    <script>
        // Function to fetch cart items and render them
        function renderCart() {
            fetch('fetch_cart.php')
                .then(response => response.json())
                .then(data => {
                    const cartItemsContainer = document.getElementById('cart-items');
                    const totalItemsElement = document.getElementById('total-items');
                    const totalPriceElement = document.getElementById('total-price');
    
                    cartItemsContainer.innerHTML = ''; // Clear current items
    
                    let totalItems = 0;
                    let totalPrice = 0;
    
                    // Loop through cart items and render them
                    data.cart.forEach(item => {
                        totalItems += item.quantity;
                        totalPrice += item.price * item.quantity;
    
                        const row = document.createElement('tr');
                       
                        cartItemsContainer.appendChild(row);
                    });
    
                    // Update cart summary
                    totalItemsElement.textContent = totalItems;
                    totalPriceElement.textContent = totalPrice.toFixed(2);
                })
                .catch(error => console.error('Error fetching cart:', error));
        }
    
        // Function to remove an item from the cart
        function removeFromCart(itemId) {
            fetch('remove_from_cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `id=${itemId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    renderCart(); // Refresh the cart
                } else {
                    alert('Failed to remove item from cart');
                }
            })
            .catch(error => console.error('Error removing item from cart:', error));
        }
    
        // Initialize cart display on page load
        window.onload = renderCart;
    </script>
    
    
    <script>
    document.getElementById('checkout-button').addEventListener('click', function () {
        // Store the total price in localStorage to pass it to checkout.html
        const totalPrice = document.getElementById('total-price').textContent;
        localStorage.setItem('total_price', totalPrice);

        // Redirect to checkout.html
        window.location.href = 'checkout.html';
    });
</script>

</body>
</html>

