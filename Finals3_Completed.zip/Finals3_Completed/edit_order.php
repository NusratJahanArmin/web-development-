<?php
include 'connect.php';
session_start();

// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

$orderData = $_SESSION['order']; // Retrieve order data
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order - GlamGrove</title>
    <link rel="stylesheet" href="styles.css">
    <style>
         /* General Page Styling */
         .edit-page {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #f9f9f9;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
    
        h2 {
            text-align: center;
            font-size: 32px;
            color: #333;
            margin-bottom: 30px;
        }
    
        h3 {
            margin-top: 20px;
            color: #444;
            font-size: 24px;
        }
        h4
        {
            text-align: center;
            color: #333;
            
        }
        .submit-button
        {
             display: inline-block;
    background-color: #ff5f6d;
    color: white;
    padding: 7px 9px;
    font-size: 18px;
    text-decoration: none;
    border: none;
    min-width: 100px;
    border-radius: 30px;
    box-shadow: 0 4px 8px rgba(217, 213, 213, 0.521);
    transition: transform 0.3s ease, background-color 0.3s ease, background 0.5s ease;
        }
        .submit-button:hover
        {
            animation: pulse 1.5s infinite; /* Pulsing effect */
    transform: scale(1.05); /* Slight zoom */
    background: linear-gradient(135deg, #ff5f6d, #ffc371); /* Gradient transition */
        }
        .billing-form {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }
    
        .billing-info,
        .payment-methods,
        .payment-details,
        .order-summary {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
    
        .billing-info label {
            display: block;
            font-weight: bold;
            color: #555;
            margin-bottom: 8px;
        }
    
        .billing-info input,
        .billing-info textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
    
        .billing-info textarea {
            resize: vertical;
            min-height: 80px;
        }
    
        .payment-methods {
            display: flex;
            justify-content: space-around;
        }
    
        .payment-methods label {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }
    
        .payment-methods input {
            display: none;
        }
    
        .payment-methods img {
            width: 50px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
    
        .payment-methods input:checked + img {
            transform: scale(1.1);
            border: 2px solid #ff5f6d;
            border-radius: 10px;
        }
    
        .order-summary p {
            font-size: 18px;
            color: #555;
            margin: 10px 0;
        }
    
        .submit-button {
            width: 100%;
            padding: 15px;
            font-size: 18px;
            font-weight: bold;
            color: white;
            background-color: #ff5f6d;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
    
        .submit-button:hover {
            background-color: #e04a58;
            transform: scale(1.05);
        }
    
        .hidden {
            display: none;
        }
    
        /* Responsive Design */
        @media (max-width: 768px) {
            .payment-methods {
                flex-wrap: wrap;
                justify-content: center;
                gap: 20px;
            }
        }
        /* General Dark Mode Styling */
body.dark-mode {
    background-color: #1e1e1e;
    color: #e0e0e0;
    transition: background-color 0.3s ease, color 0.3s ease;
}

/* Dark Mode for Sticky Header */
body.dark-mode .sticky-header {
    background-color: #333;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

body.dark-mode .logo,
body.dark-mode nav a {
    color: #e0e0e0;
}

body.dark-mode .logo:hover,
body.dark-mode nav a:hover {
    color: #ff5f6d;
}

/* Dark Mode for Checkout Page */
body.dark-mode .checkout-page {
    background-color: #333;
    color: #e0e0e0;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
}

body.dark-mode .billing-info,
body.dark-mode .payment-methods,
body.dark-mode .order-summary {
    background-color: #333;
    color: #e0e0e0;
    border: 1px solid #666;
}

body.dark-mode .billing-info input,
body.dark-mode .billing-info textarea,
body.dark-mode .payment-methods img {
    background-color: #444;
    color: #e0e0e0;
    border: 1px solid #555;
}

body.dark-mode .billing-info label,
body.dark-mode .order-summary p,
body.dark-mode h2,
body.dark-mode h3,
body.dark-mode h4 {
    color: white;
}

/* Dark Mode Buttons */
body.dark-mode .submit-button {
    background-color: #fe7681;
    color: #333;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

body.dark-mode .submit-button:hover {
    background-color: #ff5f6d;
    color: white;
    transform: scale(1.05);
}

body.dark-mode .payment-methods input:checked + img {
    border-color: #fe7681;
    box-shadow: 0 0 15px rgb(255, 0, 0);
}

/* Dark Mode Footer */
body.dark-mode footer {
    background-color: #222;
    color: #ffc371;
}

body.dark-mode footer p {
    color: #ffc371;
}

/* Vibrant Gradient Background for Dark Mode */
body.dark-mode::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #020c07, #fe7681);
    z-index: -1;
    opacity: 0.5;
}

/* Responsive Adjustments for Dark Mode */
@media (max-width: 768px) {
    body.dark-mode .checkout-page {
        padding: 20px;
    }

    body.dark-mode .edit-info,
    body.dark-mode .payment-methods,
    body.dark-mode .order-summary {
        margin-bottom: 20px;
    }
}
/* Dark Mode Styling for Payment Details */
body.dark-mode .payment-details {
    background-color: #333;
    color: #e0e0e0;
    border: 1px solid #666;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    transition: background-color 0.3s ease, color 0.3s ease;
}
body.dark-mode .edit-page h2
{
    color : black;
}
body.dark-mode .edit-info label
{
color : black;
}
body.dark-mode .payment-details h4 {
    color: #ffffff;
    font-size: 20px;
    margin-bottom: 15px;
}

body.dark-mode .payment-details label {
    color: black;
    font-weight: bold;
    margin-bottom: 5px;
    display: block;
}

body.dark-mode .payment-details input {
    background-color: #444;
    color: #e0e0e0;
    border: 1px solid #555;
    padding: 10px;
    border-radius: 5px;
    width: 100%;
    margin-bottom: 15px;
    font-size: 16px;
}

body.dark-mode .payment-details input::placeholder {
    color: #aaa;
}

body.dark-mode .payment-details p {
    color: #e0e0e0;
    font-size: 16px;
}

body.dark-mode .payment-details input:focus {
    outline: none;
    border-color: #ff5f6d;
    box-shadow: 0 0 5px rgba(255, 95, 109, 0.5);
}

/* Styling for Hidden Payment Options */
body.dark-mode .hidden {
    display: none;
}
    </style>
</head>
<body>
    <header class="sticky-header">
        <div class="nav-container">
            <a href="welcome.html" class="logo">GlamGrove</a>
            <nav>
            <a href="welcome.html">Home</a>
                <a href="shop.html">Shop</a>
                <a href="exclusive-deals.html">Exclusive Deals</a> 
                <a href="wishlist.html">Wishlist</a>
                <a href="contact.html">Contract Us</a>
                <a href="index.html">Login</a>
                <button id="dark-mode-toggle" aria-label="Toggle Dark Mode">🌙</button>
            </nav>
        </div>
    </header>

    <main class="edit-page">
        <br>
        <h2>Edit Order Information</h2>
        <form action="update_order.php" method="POST" class="billing-form">
            <div class="edit-info">
                <label for="full-name">Full Name:</label>
                <input type="text" id="full-name" name="full_name" value="<?= htmlspecialchars($orderData['full_name']); ?>" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($orderData['email']); ?>" required>

                <label for="billing-address">Billing Address:</label>
                <textarea id="billing-address" name="billing_address" required><?= htmlspecialchars($orderData['billing_address']); ?></textarea>

                <label for="city">City:</label>
                <input type="text" id="city" name="city" value="<?= htmlspecialchars($orderData['city']); ?>" required>

                <label for="postcode">Postal Code:</label>
                <input type="text" id="postcode" name="postal_code" value="<?= htmlspecialchars($orderData['postal_code']); ?>" required>

                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($orderData['phone']); ?>" required>
            </div>

            <!-- Payment Summary -->
            <div class="order-summary">
                <h4>Order Summary</h4>
                <p>Total Price: $<?= htmlspecialchars(number_format($orderData['total_price'], 2)); ?></p>
                <p>Payment Method: <?= htmlspecialchars(ucfirst($orderData['payment_method'])); ?></p>
                <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
              
            </div>

            <button type="submit" class="submit-button">Update & Confirm</button>
        </form>
    </main>

       <!-- Dark Mode JavaScript -->
       <script>
    // Select the dark mode toggle button
    const darkModeToggle = document.getElementById("dark-mode-toggle");

    // Check if dark mode was previously enabled
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        darkModeToggle.textContent = "☀️"; // Sun icon for light mode
    }

    // Toggle dark mode on button click
    darkModeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        
        if (document.body.classList.contains("dark-mode")) {
            // Enable dark mode
            localStorage.setItem("darkMode", "enabled");
            darkModeToggle.textContent = "☀️"; // Update to sun icon
        } else {
            // Disable dark mode
            localStorage.setItem("darkMode", "disabled");
            darkModeToggle.textContent = "🌙"; // Update to moon icon
        }
    });
</script>
</body>
</html>
