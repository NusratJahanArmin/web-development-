<?php
include 'connect.php'; // Database connection
session_start();

// Replace with dynamic user ID
$userId = 1;

$query = "SELECT product_name AS name, price, quantity FROM cart WHERE user_id = $userId";
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$cartItems = [];
$totalPrice = 0;

while ($row = $result->fetch_assoc()) {
    $cartItems[] = [
        'name' => $row['name'], 
        'price' => (float)$row['price'], 
        'quantity' => (int)$row['quantity']
    ];
    $totalPrice += $row['price'] * $row['quantity'];
}

if (empty($cartItems)) {
    echo json_encode(['cart' => [], 'totalPrice' => 0]);
} else {
    echo json_encode(['cart' => $cartItems, 'totalPrice' => $totalPrice]);
}
?>
