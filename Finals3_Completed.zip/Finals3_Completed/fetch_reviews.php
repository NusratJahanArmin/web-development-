<?php
include 'connect.php';

$product_name = $conn->real_escape_string($_GET['product_name']);

$sql = "SELECT reviews.review_text, reviews.rating, users.name AS user_name
        FROM reviews
        JOIN users ON reviews.user_id = users.id
        WHERE reviews.product_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $product_name);
$stmt->execute();
$result = $stmt->get_result();

$reviews = [];
while ($row = $result->fetch_assoc()) {
    $reviews[] = $row;
}

echo json_encode($reviews);

$stmt->close();
$conn->close();
?>
