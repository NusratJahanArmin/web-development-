<?php
include 'connect.php'; // Database connection
session_start();

// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

// Retrieve all wishlist items for the user
$sql = "SELECT product_name, price, image_url FROM wishlist WHERE user_id = $userId";
$result = $conn->query($sql);

$wishlist = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $wishlist[] = $row;
    }
}

// Send wishlist data as JSON
echo json_encode($wishlist);

$conn->close();
?>