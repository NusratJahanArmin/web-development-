<?php
include 'connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Check if the email exists
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Login successful
            $_SESSION['user'] = $user;
            echo "Login successful!";
            header("Location: welcome.html"); // Redirect to welcome page
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No account found with that email!";
    }
}
?>

