<?php
session_start();


// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Summary - GlamGrove</title>
    <link rel="stylesheet" href="styles.css">
    <style>
  
/* Main Styling */
main.summary-page {
    padding: 40px 20px;
    text-align: center;
}

main.summary-page h2 {
    font-size: 2.5rem;
    margin-bottom: 30px;
    color: #444;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
}

.container {
    max-width: 850px;
    margin: 0 auto;
    background: linear-gradient(135deg, #fff, #f7f9fc);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.15);
    transition: transform 0.3s ease;
}

.container:hover {
    transform: translateY(-10px);
}

.container h1 {
    font-size: 2rem;
    margin-bottom: 20px;
    color: #333;
}

.container p {
    margin: 15px 0;
    font-size: 1.2rem;
    color: #666;
    line-height: 1.8;
    text-align: left;
}

.container p strong {
    color: #333;
    font-weight: 600;
}

.container .btn {
   
    display: inline-block;
    background-color: #ff5f6d;
    color: white;
    padding: 7px 9px;
    font-size: 18px;
    text-decoration: none;
    border: none;
    min-width: 100px;
    border-radius: 30px;
    box-shadow: 0 4px 8px rgba(217, 213, 213, 0.521);
    transition: transform 0.3s ease, background-color 0.3s ease, background 0.5s ease;
}

.container .btn:hover {
    animation: pulse 1.5s infinite; /* Pulsing effect */
    transform: scale(1.05); /* Slight zoom */
    background: linear-gradient(135deg, #ff5f6d, #ffc371); /* Gradient transition */
}
/* Uniform alignment and spacing */
.container .btn + .btn {
    margin-left: 10px; /* Space between buttons */
}
/* Footer Buttons Alignment */
.container a.btn {
    margin-right: 10px;
}

body.dark-mode .container
{
    max-width: 850px;
    margin: 0 auto;
    background: black;
    color : white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.15);
    transition: transform 0.3s ease;

}

body.dark-mode .container:hover {
    transform: translateY(-10px);
}

body.dark-mode .container h1 {
    font-size: 2rem;
    margin-bottom: 20px;
    color: white;
}

body.dark-mode .container p {
    margin: 15px 0;
    font-size: 1.2rem;
    color:white;
    line-height: 1.8;
    text-align: left;
}

body.dark-mode .container p strong {
    color:white;
    font-weight: 600;
}
body.dark-mode .btn {
    background-color: #fe7681;
    color: #333;
    transition: background-color 0.3s ease;
}

body.dark-mode .btn:hover {
    background-color: #ffc371;
    color: #333;
}

    </style>
</head>
<body>
    <header class="sticky-header">
        <div class="nav-container">
            <a href="welcome.html" class="logo">GlamGrove</a>
            <nav>
            <a href="welcome.html">Home</a>
                <a href="shop.html">Shop</a>
                <a href="exclusive-deals.html">Exclusive Deals</a> 
                <a href="wishlist.html">Wishlist</a>
                <a href="contact.html">Contract Us</a>
                <a href="index.html">Login</a>
                <button id="dark-mode-toggle" aria-label="Toggle Dark Mode">🌙</button>
            </nav>
        </div>
    </header>

    <main class="summary-page">
        <br><br>
        <div class="container">
        <h1>Order Summary</h1>
        <p><strong>Full Name        :</strong> <?php echo isset($_SESSION['order']['full_name']) ? htmlspecialchars($_SESSION['order']['full_name']) : 'N/A'; ?></p>
        <p><strong>Email            :</strong> <?php echo isset($_SESSION['order']['email']) ? htmlspecialchars($_SESSION['order']['email']) : 'N/A'; ?></p>
        <p><strong>Billing Address  :</strong> <?php echo isset($_SESSION['order']['billing_address']) ? htmlspecialchars($_SESSION['order']['billing_address']) : 'N/A'; ?></p>
        <p><strong>City             :</strong> <?php echo isset($_SESSION['order']['city']) ? htmlspecialchars($_SESSION['order']['city']) : 'N/A'; ?></p>
        <p><strong>Postal Code      :</strong> <?php echo isset($_SESSION['order']['postal_code']) ? htmlspecialchars($_SESSION['order']['postal_code']) : 'N/A'; ?></p>
        <p><strong>Phone            :</strong> <?php echo isset($_SESSION['order']['phone']) ? htmlspecialchars($_SESSION['order']['phone']) : 'N/A'; ?></p>
        <p><strong>Payment Method   :</strong> <?php echo isset($_SESSION['order']['payment_method']) ? htmlspecialchars($_SESSION['order']['payment_method']) : 'N/A'; ?></p>
        <p><strong>Total Price      :</strong> $<?php echo isset($_SESSION['order']['total_price']) ? number_format($_SESSION['order']['total_price'], 2) : '0.00'; ?></p>
        <a href="edit_order.php" class="btn">Edit</a>
        <a href="shop.html" class="btn">Confirm</a>
    </div>
    </main>

    <script>
        // Load order details from localStorage (or fetch from server)
        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('summary-full-name').textContent = localStorage.getItem('full_name');
            document.getElementById('summary-email').textContent = localStorage.getItem('email');
            document.getElementById('summary-billing-address').textContent = localStorage.getItem('billing_address');
            document.getElementById('summary-city').textContent = localStorage.getItem('city');
            document.getElementById('summary-postcode').textContent = localStorage.getItem('postal_code');
            document.getElementById('summary-phone').textContent = localStorage.getItem('phone');
            document.getElementById('summary-payment-method').textContent = localStorage.getItem('payment_method');
            document.getElementById('summary-total-price').textContent = localStorage.getItem('total_price');
        });

        // Redirect to an edit page
        function editOrder() {
            window.location.href = "edit_order.php";
        }
    </script>

     <!-- Dark Mode JavaScript -->
<script>
    // Select the dark mode toggle button
    const darkModeToggle = document.getElementById("dark-mode-toggle");

    // Check if dark mode was previously enabled
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        darkModeToggle.textContent = "☀️"; // Sun icon for light mode
    }

    // Toggle dark mode on button click
    darkModeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        
        if (document.body.classList.contains("dark-mode")) {
            // Enable dark mode
            localStorage.setItem("darkMode", "enabled");
            darkModeToggle.textContent = "☀️"; // Update to sun icon
        } else {
            // Disable dark mode
            localStorage.setItem("darkMode", "disabled");
            darkModeToggle.textContent = "🌙"; // Update to moon icon
        }
    });
</script>
</body>
</html>
