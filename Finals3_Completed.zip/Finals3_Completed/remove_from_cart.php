<?php
session_start();

// Database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'glamgrove_db';

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Remove item from cart
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cart_id = $_POST['cart_id'];
    $sql = "DELETE FROM cart WHERE id = $cart_id";
    $conn->query($sql);
}

// Redirect back to cart
$conn->close();
header("Location: cart.php");
exit();
?>
