<?php
include 'connect.php'; // Database connection
session_start();

// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

$product_name = $conn->real_escape_string($_POST['product_name']);

// Remove the product from the wishlist
$sql = "DELETE FROM wishlist WHERE user_id = $userId AND product_name = '$product_name'";
if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Product removed from wishlist!"]);
} else {
    echo json_encode(["success" => false, "message" => "Error removing product from wishlist: " . $conn->error]);
}

$conn->close();
?>
