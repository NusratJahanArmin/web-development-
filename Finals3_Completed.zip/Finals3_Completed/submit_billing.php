<?php
// Include database connection
include 'connect.php';

// Start session
session_start();

// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $billing_address = $_POST['billing_address'];
    $city = $_POST['city'];
    $postal_code = $_POST['postal_code'];
    $phone = $_POST['phone'];
    $payment_method = $_POST['payment_method'];
    $total_price = floatval($_POST['total_price']);

    // Determine payment details based on method
    $payment_details = '';
    if ($payment_method === 'visa') {
        $payment_details = $_POST['visa_number'];
    } elseif ($payment_method === 'mastercard') {
        $payment_details = $_POST['mastercard_number'];
    } elseif ($payment_method === 'paypal') {
        $payment_details = $_POST['paypal_email'];
    } elseif ($payment_method === 'bkash') {
        $payment_details = $_POST['bkash_number'];
    } elseif ($payment_method === 'nagad') {
        $payment_details = $_POST['nagad_number'];
    }

    // Store the data in session
    $_SESSION['order'] = [
        'order_id' => $order_id, // Ensure this is included
        'full_name' => $full_name,
        'email' => $email,
        'billing_address' => $billing_address,
        'city' => $city,
        'postal_code' => $postal_code,
        'phone' => $phone,
        'payment_method' => $payment_method,
        'payment_details' => $payment_details,
        'total_price' => $total_price,
    ];

    // Insert order into the database
    $sql = "INSERT INTO total_orders 
        (user_id, full_name, email, billing_address, city, postal_code, phone, payment_method, payment_details, total_price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param(
        "issssssssd",
        $userId, // User ID
        $full_name, // Full name
        $email, // Email
        $billing_address, // Billing address
        $city, // City
        $postal_code, // Postal code
        $phone, // Phone
        $payment_method, // Payment method
        $payment_details, // Payment details
        $total_price // Total price
    );

  // After successfully inserting the order into the database, retrieve the `order_id`
if ($stmt->execute()) {
    $order_id = $conn->insert_id; // Get the auto-incremented order_id
    $_SESSION['order']['order_id'] = $order_id; // Store it in the session
    header("Location: order_summary.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
