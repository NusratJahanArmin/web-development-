<?php
include 'connect.php'; // Include database connection
session_start();

// Replace with dynamic user ID
$userId = 1;

// Collect form data
$productName = $conn->real_escape_string($_POST['product_name']);
$price = floatval($_POST['price']);
$color = $conn->real_escape_string($_POST['color']);
$size = $conn->real_escape_string($_POST['size']);
$quantity = intval($_POST['quantity']);
$shippingAddress = $conn->real_escape_string($_POST['shipping_address']);
$city = $conn->real_escape_string($_POST['city']);
$postalCode = $conn->real_escape_string($_POST['postal_code']);
$phone = $conn->real_escape_string($_POST['phone']);
$paymentMethod = $conn->real_escape_string($_POST['payment_method']);
$discount_code = $conn->real_escape_string($_POST['discount_code'] ?? '');

// Calculate the total price
$shipping_cost = 10.00; // Flat shipping fee
$total_price = ($price * $quantity) + $shipping_cost;

// Apply discount if the discount code is valid
if ($discount_code === 'SAVE10') {
    $total_price *= 0.90; // Apply a 10% discount
}
// Collect payment details
$paymentDetails = '';
if ($paymentMethod === 'visa') {
    $paymentDetails = $conn->real_escape_string($_POST['visa_number']);
} elseif ($paymentMethod === 'mastercard') {
    $paymentDetails = $conn->real_escape_string($_POST['mastercard_number']);
} elseif ($paymentMethod === 'paypal') {
    $paymentDetails = $conn->real_escape_string($_POST['paypal_email']);
} elseif ($paymentMethod === 'bkash') {
    $paymentDetails = $conn->real_escape_string($_POST['bkash_number']);
} elseif ($paymentMethod === 'nagad') {
    $paymentDetails = $conn->real_escape_string($_POST['nagad_number']);
}

// Insert order into the database
$sql = "INSERT INTO orders (
            user_id, product_name, price, color, size, quantity,
            shipping_address, city, postal_code, phone, payment_method, payment_details , discount_code, total_price
        ) VALUES (
            $userId, '$productName', $price, '$color', '$size', $quantity,
            '$shippingAddress', '$city', '$postalCode', '$phone', '$paymentMethod', '$paymentDetails', '$discount_code', $total_price
        )";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Order placed successfully!'); window.location.href='shop.html';</script>";
} else {
    echo "<script>alert('Error: " . $conn->error . "'); window.history.back();</script>";
}

$conn->close();
?>
