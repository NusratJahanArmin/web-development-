<?php
include 'connect.php'; // Database connection
session_start();

// Simulating a logged-in user
$userId = 1; // Replace with session-based user ID later

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $conn->real_escape_string($_POST['product_name']); // Use product_name now
    $review_text = $conn->real_escape_string($_POST['review']);
    $rating = intval($_POST['rating']); // Rating from 1 to 5

    if (empty($review_text) || empty($product_name) || $rating < 1 || $rating > 5) {
        echo json_encode(["success" => false, "message" => "Invalid input"]);
        exit;
    }

    // Insert the review into the database
    $sql = "INSERT INTO reviews (product_name, user_id, review_text, rating) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(["success" => false, "message" => "Failed to prepare statement"]);
        exit;
    }
    $stmt->bind_param("sisi", $product_name, $userId, $review_text, $rating);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Review submitted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error submitting review"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
}
?>
