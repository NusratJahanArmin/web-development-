<?php
include 'connect.php';
session_start();

$userId = 1; // Simulating logged-in user

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user input
    $order_id = $_POST['order_id'] ?? null;
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $billing_address = $_POST['billing_address'];
    $city = $_POST['city'];
    $postal_code = $_POST['postal_code'];
    $phone = $_POST['phone'];

    // Validate `order_id`
    if (!$order_id) {
        die("Order ID is missing. Unable to update the order.");
    }

    // Update order in the database
    $stmt = $conn->prepare(
        "UPDATE total_orders SET full_name = ?, email = ?, billing_address = ?, city = ?, postal_code = ?, phone = ? WHERE order_id = ? AND user_id = ?"
    );

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param('ssssssii', $full_name, $email, $billing_address, $city, $postal_code, $phone, $order_id, $userId);

    if ($stmt->execute()) {
        echo "Order updated successfully!";
        header("Location: shop.html");
        exit();
    } else {
        echo "Failed to update the order: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}

?>
